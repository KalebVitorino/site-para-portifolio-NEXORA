(() => {
  const STORAGE_KEY = 'nexora.solicitacoes.v1';
  const READ_NOTIFICATIONS_KEY = 'nexora.notificacoes.lidas.v1';
  const els = {
    total: document.querySelector('#totalCount'), analysis: document.querySelector('#analysisCount'),
    sent: document.querySelector('#sentCount'), approved: document.querySelector('#approvedCount'),
    search: document.querySelector('#searchInput'), filter: document.querySelector('#statusFilter'),
    body: document.querySelector('#requestsBody'), tableWrap: document.querySelector('#tableWrap'), mobileList: document.querySelector('#mobileRequestList'),
    empty: document.querySelector('#emptyState'), emptyTitle: document.querySelector('#emptyTitle'),
    emptyDescription: document.querySelector('#emptyDescription'), footer: document.querySelector('#tableFooter'),
    summary: document.querySelector('#resultsSummary'), clear: document.querySelector('#clearSearch'),
    toast: document.querySelector('#toast'), notification: document.querySelector('#notificationsButton'),
    notificationDot: document.querySelector('#notificationDot'), notificationPanel: document.querySelector('#notificationPanel'),
    notificationBackdrop: document.querySelector('#notificationBackdrop'), notificationList: document.querySelector('#notificationList'),
    notificationSubtitle: document.querySelector('#notificationSubtitle'), notificationFooterText: document.querySelector('#notificationFooterText'),
    closeNotifications: document.querySelector('#closeNotifications'), detailBackdrop: document.querySelector('#detailBackdrop'),
    detailModal: document.querySelector('#detailModal'), detailContent: document.querySelector('#detailContent'),
    closeDetails: document.querySelector('#closeDetails'), closeDetailsFooter: document.querySelector('#closeDetailsFooter'), generateQuote: document.querySelector('#generateQuote')
  };
  let allRequests = [];
  let readNotificationIds = new Set();
  let notificationsOpen = false;
  let activeDetailId = null;
  let previousFocus = null;
  const safe = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const statusClass = status => ({'Pendente':'pending','Em análise':'analysis','Orçamento enviado':'sent','Aprovado':'approved','Aprovada':'approved'}[status] || 'other');
  const priorityClass = value => ({'Alta':'high','Média':'medium','Baixa':'low'}[value] || 'medium');
  const formatDate = value => { const d = new Date(value); return Number.isNaN(d.getTime()) ? '—' : new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'2-digit',year:'numeric'}).format(d); };
  const formatTime = value => { const d = new Date(value); return Number.isNaN(d.getTime()) ? '' : new Intl.DateTimeFormat('pt-BR',{hour:'2-digit',minute:'2-digit'}).format(d); };
  function showToast(message) { els.toast.textContent = message; els.toast.hidden = false; window.setTimeout(() => { els.toast.hidden = true; }, 2800); }
  function notificationId(request) { return String(request.id ?? `${request.createdAt ?? ''}|${request.name ?? ''}|${request.service ?? ''}`); }
  function loadReadNotifications() {
    try { const ids = JSON.parse(localStorage.getItem(READ_NOTIFICATIONS_KEY) || '[]'); readNotificationIds = new Set(Array.isArray(ids) ? ids.map(String) : []); }
    catch { readNotificationIds = new Set(); }
  }
  function saveReadNotifications() {
    try { localStorage.setItem(READ_NOTIFICATIONS_KEY, JSON.stringify([...readNotificationIds])); } catch { /* armazenamento local indisponível */ }
  }
  function unreadRequests() { return allRequests.filter(request => !readNotificationIds.has(notificationId(request))); }
  function updateNotificationState() {
    const unread = unreadRequests();
    const hasUnread = unread.length > 0;
    els.notification.classList.toggle('is-pending', hasUnread);
    els.notification.setAttribute('aria-expanded', String(notificationsOpen));
    els.notification.setAttribute('aria-label', hasUnread ? `Notificações, ${unread.length} não lidas` : 'Notificações');
    els.notificationDot.hidden = !hasUnread;
    els.notificationDot.setAttribute('aria-label', hasUnread ? `${unread.length} notificações não lidas` : '');
    els.notificationSubtitle.textContent = hasUnread ? `${unread.length} ${unread.length === 1 ? 'notificação nova' : 'notificações novas'}.` : 'Confira as atualizações das solicitações.';
    els.notificationFooterText.textContent = hasUnread ? 'Abra e confira para marcar como vista.' : 'Você está em dia.';
  }
  function renderNotifications() {
    const ordered = [...allRequests].sort((a,b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    if (!ordered.length) {
      els.notificationList.innerHTML = `<div class="notification-empty"><span class="notification-empty-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg></span><h3>Nenhuma notificação ainda</h3><p>Quando alguém enviar uma solicitação pelo formulário do site, você verá uma notificação aqui.</p></div>`;
      return;
    }
    els.notificationList.innerHTML = ordered.map(request => {
      const unread = !readNotificationIds.has(notificationId(request));
      const name = request.name || 'Novo solicitante';
      const service = request.service || 'serviço de manutenção';
      const status = request.status || 'Pendente';
      return `<article class="notification-item ${unread ? 'is-unread' : ''}">
        <span class="notification-item-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h6"/></svg></span>
        <div><p class="notification-item-title">${safe(unread ? 'Nova solicitação recebida' : 'Solicitação registrada')}${unread ? '<span class="notification-unread-dot" aria-label="Não lida"></span>' : ''}</p>
        <p class="notification-item-text"><strong>${safe(name)}</strong> enviou uma solicitação de ${safe(service.toLocaleLowerCase('pt-BR'))}.</p>
        <div class="notification-item-meta"><span>${safe(formatDate(request.createdAt))}${formatTime(request.createdAt) ? ` • ${safe(formatTime(request.createdAt))}` : ''}</span><span class="notification-status">${safe(status)}</span></div></div>
      </article>`;
    }).join('');
  }
  function openNotifications() {
    notificationsOpen = true;
    renderNotifications();
    updateNotificationState();
    els.notificationPanel.hidden = false;
    els.notificationBackdrop.hidden = false;
    els.notificationPanel.setAttribute('aria-hidden', 'false');
    els.notification.setAttribute('aria-expanded', 'true');
    els.closeNotifications.focus({ preventScroll: true });
  }
  function closeNotifications(markViewed = true) {
    if (!notificationsOpen) return;
    if (markViewed) {
      allRequests.forEach(request => readNotificationIds.add(notificationId(request)));
      saveReadNotifications();
    }
    notificationsOpen = false;
    els.notificationPanel.hidden = true;
    els.notificationBackdrop.hidden = true;
    els.notificationPanel.setAttribute('aria-hidden', 'true');
    updateNotificationState();
    if (markViewed) renderNotifications();
  }
  function loadRequests() {
    try { const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); allRequests = Array.isArray(parsed) ? parsed : []; }
    catch { allRequests = []; }
    updateCounts();
    render();
    if (notificationsOpen) renderNotifications();
  }
  function updateCounts() {
    els.total.textContent = allRequests.length;
    els.analysis.textContent = allRequests.filter(r => ['Pendente','Em análise'].includes(r.status)).length;
    els.sent.textContent = allRequests.filter(r => r.status === 'Orçamento enviado').length;
    els.approved.textContent = allRequests.filter(r => ['Aprovado','Aprovada'].includes(r.status)).length;
    updateNotificationState();
  }
  function render() {
    const q = els.search.value.trim().toLocaleLowerCase('pt-BR');
    const status = els.filter.value;
    const filtered = allRequests.filter(r => {
      const text = [r.name,r.company,r.service,r.email,r.location].join(' ').toLocaleLowerCase('pt-BR');
      return (!q || text.includes(q)) && (status === 'all' || r.status === status);
    });
    els.body.innerHTML = filtered.map(r => `<tr>
      <td class="date-cell">${safe(formatDate(r.createdAt))}<br>${safe(formatTime(r.createdAt))}</td>
      <td><span class="person-name">${safe(r.name || 'Nome não informado')}</span><span class="person-company">${safe(r.company || 'Pessoa física')}</span></td>
      <td class="service-cell">${safe(r.service || 'Serviço não informado')}</td>
      <td><span class="priority ${priorityClass(r.urgency)}">${safe(r.urgency || 'Média')}</span></td>
      <td><span class="status-pill ${statusClass(r.status)}">${safe(r.status || 'Pendente')}</span></td>
      <td><button class="details-button" type="button" data-detail="${safe(r.id)}">Ver detalhes</button></td>
    </tr>`).join('');
    els.mobileList.innerHTML = filtered.map(r => `<article class="mobile-request-card">
      <span class="mobile-request-meta">${safe(formatDate(r.createdAt))} • ${safe(formatTime(r.createdAt))}</span>
      <div><span class="mobile-request-name">${safe(r.name || 'Nome não informado')}</span><span class="mobile-request-company">${safe(r.company || 'Pessoa física')}</span><span class="mobile-request-service">${safe(r.service || 'Serviço não informado')}</span></div>
      <div class="mobile-request-right"><span class="priority ${priorityClass(r.urgency)}">${safe(r.urgency || 'Média')}</span><span class="status-pill ${statusClass(r.status)}">${safe(r.status || 'Pendente')}</span></div>
      <button class="details-button" type="button" data-detail="${safe(r.id)}">Ver detalhes</button>
    </article>`).join('');
    const hasRows = filtered.length > 0;
    els.tableWrap.hidden = !hasRows;
    els.empty.hidden = hasRows;
    els.footer.hidden = !hasRows;
    if (!hasRows && allRequests.length && (q || status !== 'all')) {
      els.emptyTitle.textContent = 'Nenhum resultado encontrado';
      els.emptyDescription.textContent = 'Tente alterar a busca ou o filtro de status.';
    } else {
      els.emptyTitle.textContent = 'Nenhuma solicitação ainda';
      els.emptyDescription.textContent = 'As solicitações enviadas pelo formulário do site aparecerão aqui automaticamente.';
    }
    els.summary.textContent = `${filtered.length} ${filtered.length === 1 ? 'solicitação encontrada' : 'solicitações encontradas'}`;
  }
  function detailSection(icon, title, content) {
    return `<section class="detail-section"><h3><span class="detail-section-icon">${icon}</span>${title}</h3>${content}</section>`;
  }
  function openDetails(request) {
    activeDetailId = String(request.id);
    previousFocus = document.activeElement;
    const id = request.id ? String(request.id) : '—';
    const created = `${formatDate(request.createdAt)}${formatTime(request.createdAt) ? ` às ${formatTime(request.createdAt)}` : ''}`;
    const status = request.status || 'Pendente';
    const attachments = Array.isArray(request.attachments) ? request.attachments : (Array.isArray(request.files) ? request.files : []);
    const contactRows = [
      ['Nome completo', request.name], ['Empresa / Condomínio', request.company],
      ['Telefone', request.phone], ['E-mail', request.email]
    ].filter(row => row[1]);
    const serviceRows = [['Tipo de serviço', request.service], ['Descrição', request.description]].filter(row => row[1]);
    const extraRows = [['Prioridade', request.urgency], ['Melhor período', request.bestTime || request.preferredTime], ['Local do serviço', request.location]].filter(row => row[1]);
    const rows = list => `<dl class="detail-data-grid">${list.map(([label,value]) => `<div class="detail-data-row"><dt>${safe(label)}</dt><dd>${safe(value)}</dd></div>`).join('')}</dl>`;
    const fileContent = attachments.length ? `<div class="detail-attachments">${attachments.map(file => {
      const name = typeof file === 'string' ? file : (file.name || 'Arquivo anexado');
      const url = typeof file === 'object' ? file.url || file.dataUrl || '' : '';
      return `<div class="detail-attachment"><span class="detail-attachment-icon">↗</span><span>${safe(name)}</span>${url && /^https?:|^data:image\//i.test(url) ? `<a href="${safe(url)}" target="_blank" rel="noopener">Abrir</a>` : ''}</div>`;
    }).join('')}</div>` : `<p class="detail-no-files">Nenhum arquivo foi anexado a esta solicitação.</p>`;
    els.detailContent.innerHTML = `
      <div class="detail-request-summary"><span class="detail-summary-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h6"/></svg></span><div class="detail-summary-copy"><strong>#NEX-${safe(id)}</strong><span>Recebida em ${safe(created)}</span></div><span class="status-pill ${statusClass(status)}">${safe(status)}</span></div>
      ${detailSection('<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>', 'Dados do solicitante', rows(contactRows.length ? contactRows : [['Dados','Não informados']]))}
      ${detailSection('<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14.7 6.3 3-3a4 4 0 0 1-5.4 5.4L6 15l-2 5 5-2 6.3-6.3a4 4 0 0 1 5.4-5.4l-3 3"/></svg>', 'Serviço solicitado', rows(serviceRows.length ? serviceRows : [['Descrição','Não informada']]))}
      ${detailSection('<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg>', 'Informações adicionais', rows(extraRows.length ? extraRows : [['Prioridade','Não informada']]))}
      ${detailSection('<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m21 11.5-8.5 8.5a5 5 0 0 1-7-7L14 4.5a3.5 3.5 0 0 1 5 5L10.5 18a2 2 0 0 1-3-3l8-8"/></svg>', 'Arquivos anexados', fileContent)}`;
    els.generateQuote.disabled = status === 'Orçamento enviado' || ['Aprovado','Aprovada'].includes(status);
    els.generateQuote.innerHTML = els.generateQuote.disabled ? 'Orçamento já enviado' : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h5"/></svg>Gerar orçamento';
    els.detailModal.hidden = false;
    els.detailBackdrop.hidden = false;
    els.detailModal.setAttribute('aria-hidden','false');
    document.body.classList.add('modal-open');
    els.closeDetails.focus({preventScroll:true});
  }
  function closeDetails() {
    if (els.detailModal.hidden) return;
    els.detailModal.hidden = true;
    els.detailBackdrop.hidden = true;
    els.detailModal.setAttribute('aria-hidden','true');
    document.body.classList.remove('modal-open');
    activeDetailId = null;
    if (previousFocus && typeof previousFocus.focus === 'function') previousFocus.focus({preventScroll:true});
  }
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-detail]');
    if (!button) return;
    const request = allRequests.find(r => String(r.id) === button.dataset.detail);
    if (request) openDetails(request);
  });
  els.closeDetails.addEventListener('click', closeDetails);
  els.closeDetailsFooter.addEventListener('click', closeDetails);
  els.detailBackdrop.addEventListener('click', closeDetails);
  els.generateQuote.addEventListener('click', () => {
    const request = allRequests.find(r => String(r.id) === activeDetailId);
    if (!request || els.generateQuote.disabled) return;
    request.status = 'Orçamento enviado';
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(allRequests)); } catch { showToast('Não foi possível salvar a alteração neste navegador.'); return; }
    updateCounts(); render(); renderNotifications();
    closeDetails();
    showToast('Solicitação atualizada para “Orçamento enviado”.');
  });
  els.search.addEventListener('input', render);
  els.filter.addEventListener('change', render);
  els.clear.addEventListener('click', () => { els.search.value = ''; els.filter.value = 'all'; render(); });
  els.notification.addEventListener('click', () => notificationsOpen ? closeNotifications(true) : openNotifications());
  els.closeNotifications.addEventListener('click', () => closeNotifications(true));
  els.notificationBackdrop.addEventListener('click', () => closeNotifications(true));
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !els.detailModal.hidden) { closeDetails(); return; } if (event.key === 'Escape' && notificationsOpen) { closeNotifications(true); els.notification.focus({ preventScroll: true }); } });
  document.addEventListener('click', event => {
    if (notificationsOpen && !els.notificationPanel.contains(event.target) && !els.notification.contains(event.target)) closeNotifications(true);
  });
  window.addEventListener('storage', event => { if (event.key === STORAGE_KEY) { loadRequests(); if (!els.detailModal.hidden && activeDetailId) { const current = allRequests.find(r => String(r.id) === activeDetailId); if (current) openDetails(current); else closeDetails(); } } if (event.key === READ_NOTIFICATIONS_KEY) { loadReadNotifications(); updateNotificationState(); renderNotifications(); } });
  window.addEventListener('pageshow', loadRequests);
  loadReadNotifications();
  loadRequests();
})();