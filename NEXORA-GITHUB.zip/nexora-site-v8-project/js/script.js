(() => {
  const STORAGE_KEY = "nexora.solicitacoes.v1";
  const form = document.querySelector("#requestForm");
  const successMessage = document.querySelector("#successMessage");
  const newRequestButton = document.querySelector("#newRequest");
  const phoneInput = document.querySelector("#phone");
  const menuToggle = document.querySelector("#menuToggle");
  const mainNav = document.querySelector("#mainNav");

  document.querySelector("#year").textContent = new Date().getFullYear();

  menuToggle.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Fechar menu" : "Abrir menu");
  });
  mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Abrir menu");
  }));


  // Same-page section navigation without polluting browser history.
  // This keeps the browser's Back button for actual page navigation.
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", event => {
      const targetId = link.getAttribute("href").slice(1);
      const target = document.getElementById(targetId);
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
      // Close the mobile menu if a section link was selected.
      if (mainNav && menuToggle) {
        mainNav.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Abrir menu");
      }
    });
  });


  // Same-page section navigation without polluting browser history.
  // The browser Back button remains reserved for actual page navigation.
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", event => {
      const target = document.getElementById(link.getAttribute("href").slice(1));
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
      if (mainNav && menuToggle) {
        mainNav.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Abrir menu");
      }
    });
  });

  phoneInput.addEventListener("input", () => {
    let digits = phoneInput.value.replace(/\D/g, "").slice(0, 11);
    if (digits.length > 10) digits = digits.replace(/^(\d{2})(\d{5})(\d{0,4}).*/, "($1) $2-$3");
    else if (digits.length > 6) digits = digits.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, "($1) $2-$3");
    else if (digits.length > 2) digits = digits.replace(/^(\d{2})(\d{0,5})/, "($1) $2");
    else if (digits.length > 0) digits = digits.replace(/^(\d*)/, "($1");
    phoneInput.value = digits;
  });

  function showError(field, message) {
    const wrapper = field.closest(".field");
    wrapper.classList.toggle("invalid", Boolean(message));
    wrapper.querySelector(".error-message").textContent = message || "";
    field.setAttribute("aria-invalid", String(Boolean(message)));
  }

  function validateField(field) {
    const value = field.value.trim();
    let message = "";
    if (field.required && !value) message = "Este campo é obrigatório.";
    else if (field.name === "name" && value.length < 2) message = "Informe seu nome completo.";
    else if (field.type === "email" && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) message = "Informe um e-mail válido.";
    else if (field.name === "phone" && value.replace(/\D/g, "").length < 10) message = "Informe um telefone válido com DDD.";
    else if (field.name === "description" && value.length < 10) message = "Descreva o problema com pelo menos 10 caracteres.";
    showError(field, message);
    return !message;
  }

  const fields = [...form.querySelectorAll("input, select, textarea")];
  fields.forEach(field => {
    field.addEventListener("blur", () => validateField(field));
    field.addEventListener("input", () => {
      if (field.closest(".field").classList.contains("invalid")) validateField(field);
    });
    field.addEventListener("change", () => {
      if (field.closest(".field").classList.contains("invalid")) validateField(field);
    });
  });

  form.addEventListener("submit", event => {
    event.preventDefault();
    const valid = fields.map(validateField).every(Boolean);
    if (!valid) {
      form.querySelector(".field.invalid input, .field.invalid select, .field.invalid textarea")?.focus();
      return;
    }

    const request = {
      id: (crypto.randomUUID ? crypto.randomUUID() : `req-${Date.now()}-${Math.random().toString(16).slice(2)}`),
      name: form.elements.name.value.trim(),
      company: form.elements.company.value.trim(),
      email: form.elements.email.value.trim(),
      phone: form.elements.phone.value.trim(),
      service: form.elements.service.value,
      urgency: form.elements.urgency.value,
      location: form.elements.location.value.trim(),
      description: form.elements.description.value.trim(),
      status: "Pendente",
      createdAt: new Date().toISOString()
    };

    try {
      const existing = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      if (!Array.isArray(existing)) throw new Error("Formato de dados inválido");
      existing.unshift(request);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(existing));
      form.hidden = true;
      document.querySelector(".form-heading").hidden = true;
      successMessage.hidden = false;
      successMessage.querySelector("h3").focus?.();
    } catch (error) {
      alert("Não foi possível salvar a solicitação neste navegador. Verifique se o armazenamento está disponível e tente novamente.");
      console.error("Falha ao salvar solicitação Nexora:", error);
    }
  });

  newRequestButton.addEventListener("click", () => {
    form.reset();
    fields.forEach(field => showError(field, ""));
    form.hidden = false;
    document.querySelector(".form-heading").hidden = false;
    successMessage.hidden = true;
    document.querySelector("#name").focus();
  });
})();
