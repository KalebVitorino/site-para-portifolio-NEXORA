(() => {
  const form = document.querySelector('#loginForm');
  const password = document.querySelector('#password');
  const toggle = document.querySelector('#togglePassword');
  toggle.addEventListener('click', () => {
    const showing = password.type === 'text';
    password.type = showing ? 'password' : 'text';
    toggle.setAttribute('aria-label', showing ? 'Mostrar senha' : 'Ocultar senha');
  });
  form.addEventListener('submit', event => {
    event.preventDefault();
    // Demonstração: não há autenticação real nem backend.
    window.location.href = 'dashboard.html';
  });
})();