# Nexora — Manutenção Predial

Projeto demonstrativo front-end, sem backend, com três páginas responsivas.

## Estrutura
- `html/index.html`: página inicial com apresentação dos serviços e formulário de solicitação.
- `html/login.html`: tela de login demonstrativa, com e-mail e senha fictícios preenchidos.
- `html/dashboard.html`: painel administrativo que lê as solicitações enviadas pelo formulário.
- `css/styles.css`: estilos da página inicial.
- `css/login.css`: estilos da tela de login.
- `css/dashboard.css`: estilos do painel administrativo para computador e celular.
- `js/script.js`: validação e armazenamento local das solicitações (`localStorage`).
- `js/login.js`: alternância de visibilidade da senha e encaminhamento para o painel.
- `js/dashboard.js`: contadores, busca, filtros, janela responsiva de detalhes e ação demonstrativa para marcar orçamento como enviado.

## Como abrir
Abra `html/index.html` no navegador. Use **Acessar painel** para abrir o login. No login, clique em **Entrar no painel**. No painel, clique no perfil do administrador ou no logotipo para voltar ao login.

## Demonstração
O projeto não possui backend nem autenticação real. As solicitações ficam salvas no `localStorage` do navegador e são lidas pelo painel no mesmo navegador. Por ser um protótipo aberto diretamente como arquivo local, o comportamento do armazenamento pode variar conforme o navegador; para uma demonstração mais consistente, use as páginas na mesma origem/servidor local. Os contadores começam em zero quando não há solicitações salvas. As imagens da página inicial, o fundo do login e a fonte são carregados pela internet.


## Recursos visuais locais
As fotografias utilizadas nas páginas estão em `assets/images/` e são referenciadas por caminhos relativos no CSS. A fonte Inter ainda é carregada pelo Google Fonts, portanto a tipografia pode usar uma fonte substituta se não houver internet.

## Imagens locais do projeto
As imagens em `assets/images/` são arquivos locais preparados a partir de imagens originais geradas por IA para a identidade visual da Nexora. Não dependem de links externos para carregar as fotografias do site.
